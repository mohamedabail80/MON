<?php 


$arr = array( '1' , '2' , '' , '3');

var_dump(empty($arr[2]));
exit;

require_once('../../../wp-load.php');

$ex = exists_table_alb('wp_automatic_camps');
var_dump($ex);
exit;
 
$my_plugin= dirname(__FILE__) .'/wp-automatic.php' ;


//wp-load
require_once( ABSPATH . 'wp-admin/includes/plugin.php' );



deactivate_plugins($my_plugin);
echo 'deactivated..';


?>